import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import {AngularFireAuthGuard} from '@angular/fire/compat/auth-guard'

const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: 'inicio',
    loadChildren: () => import('./folder/folder.module').then( m => m.FolderPageModule),
    canActivate:[AngularFireAuthGuard],
    
  },
  {
    path: 'inventario',
    loadChildren: () => import('./Inventario/inventario/inventario.module').then( m => m.InventarioPageModule),
    canActivate:[AngularFireAuthGuard]
  },
  {
    path: 'tickets',
    loadChildren: () => import('./Tickets/tickets/tickets.module').then( m => m.TicketsPageModule),
    canActivate:[AngularFireAuthGuard]
  },
  {
    path: 'login',
    loadChildren: () => import('./Login/login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'usuario',
    loadChildren: () => import('./Usuario/usuario/usuario.module').then( m => m.UsuarioPageModule),
    canActivate:[AngularFireAuthGuard]
  },
  {
    path: 'singleuser',
    canActivate:[AngularFireAuthGuard],
    loadChildren: () => import('./Usuario/SingleUser/singleuser/singleuser.module').then( m => m.SingleuserPageModule)
  },
  {
    path: 'registros',
    loadChildren: () => import('./registros/registros/registros.module').then( m => m.RegistrosPageModule)
  },
  {
    path: 'tabla',
    loadChildren: () => import('./Tickets/tabla/tabla.module').then( m => m.TablaPageModule)
  },
  {
    path: 'servicio',
    loadChildren: () => import('./servicios/servicio/servicio.module').then( m => m.ServicioPageModule)
  },
 
  {
    path: 'registro-ser',
    loadChildren: () => import('./registroSer/registro-ser/registro-ser.module').then( m => m.RegistroSerPageModule)
  }


];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
