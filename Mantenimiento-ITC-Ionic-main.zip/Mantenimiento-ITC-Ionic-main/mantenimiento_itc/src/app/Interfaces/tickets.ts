export interface Tickets {
    idTicket:string,
    aula:string,
    departamento:string,
    detalles:string,
    edificio:string,
    estado:string,
    fechaTicket:string,
    idEquipo:string,
    tecnico:string,
    tipoMantenimiento:string,
    uso:string,
    valoracion:string,
    comentario:string

}
