export interface Usuarios {
    id:string,
    Nombre:string,
    Apellido:string,
    Correo:string,
    Contraseña:string,
    Disponibilidad:string,
    Especialidad:string,
    Rol:string,
    Departamento:string
}
