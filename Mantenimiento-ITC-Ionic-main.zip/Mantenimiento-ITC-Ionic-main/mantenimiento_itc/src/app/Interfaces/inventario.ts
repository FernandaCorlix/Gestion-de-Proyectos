export interface Inventario {
   adquisicion:string,
   aula:string,
   conectividad:string,
   departamento:string,
   edificio:string,
   fechaAdquisicion:string,
   idEquipo:string,
   marca:string,
   ram:string,
   sistemaOperativo:string,
   tipo:string,
   uso:string
}
