import { Component } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { LoginPage } from './Login/login/login.page';
import { UserService } from './Servicies/user.service';
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  public type:any=localStorage.getItem('UserRol');
  public usuario:any;
  public appPages = [
    { title: 'Inventario', url: 'inventario', icon: 'desktop' },
    { title: 'Tickets', url: 'tickets', icon: 'ticket' },
  ];
  public labels = ['Family', 'Friends', 'Notes', 'Work', 'Travel', 'Reminders'];
  constructor(private login:LoginPage,private menuCtrl:MenuController,private userS:UserService) {
    this.usuario=localStorage.getItem('FullName');
  }
   
  logged:any=localStorage.getItem("logged");
  
  usuarios()
  {
    location.replace("usuario")
   
  }
  logout()
  {
    
    this.login.logOut();
    localStorage.removeItem('FullName');
   
}
sinUs()
{
  localStorage.setItem("nuevoUsuario",JSON.stringify(false));
  localStorage.setItem("currentUser",JSON.stringify(true))
  location.replace('singleuser')
}

  
}
