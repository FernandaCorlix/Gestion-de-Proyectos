import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { Inventario } from 'src/app/Interfaces/inventario';
import { LoginPage } from 'src/app/Login/login/login.page';
import { AlertsService } from 'src/app/Servicies/alerts.service';
import { InventoryService } from 'src/app/Servicies/inventory.service';

@Component({
  selector: 'app-inventario',
  templateUrl: './inventario.page.html',
  styleUrls: ['./inventario.page.scss'],
})
export class InventarioPage implements OnInit {
  public type:any=localStorage.getItem('UserRol');
  public depa:any=localStorage.getItem('UserDepartamento');
  logged:any;
  equipos:Inventario[]=[];
  constructor(private login:LoginPage,private menuCtrl: MenuController,private inv:InventoryService, private alert :AlertsService) {  }
  
  ngOnInit() {
    //this.logged=localStorage.getItem("logged")
    console.log(this.logged);
    this.obtenerEquipos();
  }
  ionViewWillEnter() {
    this.logged=localStorage.getItem("logged")
    if(this.logged==false)
    {
    this.menuCtrl.enable(false);
    }
    
   }
   nuevoEquipo()
   {
    location.replace('registros');
    localStorage.setItem('nuevoEquipo',JSON.stringify(true));
   }
   update(id:any)
   {
      localStorage.setItem('nuevoEquipo',JSON.stringify(false));
      localStorage.setItem('equipoId',JSON.stringify(id));
      location.replace('registros');
   }
   delete(id:any)
   {
    if (confirm("¿Estas seguro que deseas eliminar este equipo del inventario?")) {
      this.inv.borrarEquipo(id).then(r=>{
        this.alert.successful("Equipo eliminado con exito");
  
      }).catch(e=>{
        this.alert.error("Error: "+e.message);
      })
    
    
      }
   }
   obtenerEquipos()
   {
    this.inv.getHardware().subscribe(r=>
      {
        this.equipos=r;
        
      })
   }
  usuario()
  {
    location.replace("singleuser")
  }


}
