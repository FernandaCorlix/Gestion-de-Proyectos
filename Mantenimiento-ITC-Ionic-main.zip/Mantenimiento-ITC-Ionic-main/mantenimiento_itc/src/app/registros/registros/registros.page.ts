import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Inventario } from 'src/app/Interfaces/inventario';
import { AlertsService } from 'src/app/Servicies/alerts.service';
import { InventoryService } from 'src/app/Servicies/inventory.service';
@Component({
  selector: 'app-registros',
  templateUrl: './registros.page.html',
  styleUrls: ['./registros.page.scss'],
})
export class RegistrosPage implements OnInit {
  nuevo:any;
  equipoId:any;
  block: any=false;
  equipForm = new FormGroup({
    idEquipo:new FormControl('', [Validators.required]),
    conectividad: new FormControl('', [Validators.required]),
    uso: new FormControl('', [Validators.required]),
    ram: new FormControl('', [Validators.required]),
    fechaAdquisicion: new FormControl('', [Validators.required]),
    adquisicion: new FormControl(''),
    edificio: new FormControl('', [Validators.required]),
    aula: new FormControl('', [Validators.required]),
    tipo: new FormControl('', [Validators.required]),
    marca:new FormControl('', [Validators.required]),
    sistemaoperativo: new FormControl(''),
    departamento: new FormControl('', [Validators.required])
  });
  constructor(private inv:InventoryService,private alert:AlertsService) { }

  ngOnInit() {
    
  }

  ionViewWillEnter() {
    this.nuevo = localStorage.getItem("nuevoEquipo"); 
    this.equipoId=this.replace(localStorage.getItem('equipoId'),'"','');
    if(this.nuevo=='false')
    {
      this.getEquipo(this.equipoId);
      this.block=true;
    }

}
actualizarEquipo()
{
  let equipo:Inventario={
          idEquipo:this.equipForm.value['idEquipo'],
          conectividad:this.equipForm.value['conectividad'],
          uso:this.equipForm.value['uso'],
          ram:this.equipForm.value['ram'],
          fechaAdquisicion:this.equipForm.value['fechaAdquisicion'],
          adquisicion:this.equipForm.value['adquisicion'],
          edificio:this.equipForm.value['edificio'],
          aula:this.equipForm.value['aula'],
          tipo:this.equipForm.value['tipo'],
          marca:this.equipForm.value['marca'],
          sistemaOperativo:this.equipForm.value['sistemaoperativo'],
          departamento:this.equipForm.value['departamento']
    
  } as Inventario;
  this.inv.updateInventario(equipo).then(r=>{
    this.alert.successful("El equipo se ha actualizado con exito");
    console.log(r);
    location.replace('inventario');
  }).catch(e=>{
    this.alert.error("Error: "+e.message);
  })
}
getEquipo(id:any){
    
  this.inv.getEquipoId(id).subscribe(r=>
    {
      this.equipForm.controls.idEquipo.setValue(r.idEquipo);
      this.equipForm.controls.conectividad.setValue(r.conectividad);
      this.equipForm.controls.uso.setValue(r.uso);
      this.equipForm.controls.ram.setValue(r.ram);
      this.equipForm.controls.fechaAdquisicion.setValue(r.fechaAdquisicion);
      this.equipForm.controls.adquisicion.setValue(r.adquisicion);
      this.equipForm.controls.edificio.setValue(r.edificio);
      this.equipForm.controls.aula.setValue(r.aula);
      this.equipForm.controls.tipo.setValue(r.tipo);
      this.equipForm.controls.marca.setValue(r.marca);
      this.equipForm.controls.sistemaoperativo.setValue(r.sistemaOperativo);
      this.equipForm.controls.departamento.setValue(r.departamento);
      return r;
    })
    
}

replace(string:any,oldChar:string,newChar:string)
  {
      let len = string.length;
      let i;
      let newString:any="";
      for(i = 0; i < len; ++i)
      {
          if(string.charAt(i) == oldChar) 
              newString+= newChar;
          else
              newString += string.charAt(i);
      }
      return newString;
  }

  crearUsuario()
  {
    
      let inventario:Inventario={
        idEquipo:this.equipForm.value.idEquipo!,
        conectividad: this.equipForm.value.conectividad!,
        uso: this.equipForm.value.uso!,
        ram: this.equipForm.value.ram!,
        fechaAdquisicion: this.equipForm.value.fechaAdquisicion!,
        adquisicion: this.equipForm.value.adquisicion!,
        edificio: this.equipForm.value.edificio!,
        aula: this.equipForm.value.aula!,
        tipo: this.equipForm.value.tipo!,
        marca:this.equipForm.value.marca!,
        sistemaOperativo: this.equipForm.value.sistemaoperativo!,
        departamento: this.equipForm.value.departamento!
      } 
      this.inv.añadirEquipo(inventario).then(r=>{
        this.alert.successful("Equipo añadido exitosamente");
        location.replace('inventario');
      }).catch(e=>{
        this.alert.error("Error: "+e.message);
      })
  }
  

}
