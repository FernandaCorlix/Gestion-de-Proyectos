import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Inventario } from 'src/app/Interfaces/inventario';
import { Tickets } from 'src/app/Interfaces/tickets';
import { Usuarios } from 'src/app/Interfaces/usuarios';
import { AlertsService } from 'src/app/Servicies/alerts.service';
import { InventoryService } from 'src/app/Servicies/inventory.service';
import { TicketsService } from 'src/app/Servicies/tickets.service';
import { UserService } from 'src/app/Servicies/user.service';

@Component({
  selector: 'app-tabla',
  templateUrl: './tabla.page.html',
  styleUrls: ['./tabla.page.scss'],
})
export class TablaPage implements OnInit {
  depaSelect:any='';
  depa:Inventario[]=[];
  ticketId:any;
  nuevo:any;
  type:any;
  block: any=false;
  tecnico:Usuarios[]=[];
  idEquipo:Inventario[]=[];
  calificarP:any;
  ticketsData:any;
  ticketForm = new FormGroup({
    idTicket:new FormControl('', [Validators.required]),
    departamento: new FormControl('', [Validators.required]),
    edificio: new FormControl('', [Validators.required]),
    aula: new FormControl('', [Validators.required]),
    detalle: new FormControl('', [Validators.required]),
    mantenimiento: new FormControl('', [Validators.required]),
    uso: new FormControl('', [Validators.required]),
    fecha: new FormControl('', [Validators.required]),
    idEquipo:new FormControl('', [Validators.required]),
    tecnico: new FormControl(''),
    disponibilidad:new FormControl(''),
    especialidad:new FormControl(''),
    estado: new FormControl('', [Validators.required]),
    valoracion: new FormControl(''),
    comentario: new FormControl(''),
  });

 
  constructor(private tik:TicketsService,private alert:AlertsService,private user:UserService,private inv:InventoryService ) { }

  ngOnInit() {
    this.traerTecnicos();
    this.traerIdEquipo();
    this.type=localStorage.getItem('UserRol');
   
    
  }
  ionViewWillEnter() {
      this.nuevo = localStorage.getItem("nuevoTicket"); 
      console.log(localStorage.getItem('ticketId'));
      this.ticketId=this.replace(localStorage.getItem('ticketId'),'"','');
      if(this.nuevo =='true' && (this.type=="Secretaria"||this.type=="Tecnico"||this.type=="Jefe de Taller"))
        {
          this.ticketForm.controls.departamento.setValue(localStorage.getItem('UserDepartamento'));
        }
      if(this.nuevo=='false')
      {
        this.getTicket(this.ticketId);
        this.block=true;
      }

  }
  customPopoverOptions = {
    header: 'Tipo de mantenimiento',
    subHeader: 'Selecciona el tipo de mantenimiento requerido'
  };
  replace(string:any,oldChar:string,newChar:string)
  {
      let len = string.length;
      let i;
      let newString:any="";
      for(i = 0; i < len; ++i)
      {
          if(string.charAt(i) == oldChar) 
              newString+= newChar;
          else
              newString += string.charAt(i);
      }
      return newString;
  }
  calificar(){
    
    if(this.ticketForm.value.estado=="Terminado")
    {
      this.calificarP=true;
    }
    else{
      this.calificarP=false;
    }   
  }
  metodo()
  {
    console.log('Hola')
  }
  crearTicket()
  {
    
    let tickets:Tickets={
        idTicket:this.ticketForm.value.idTicket!,
        departamento: this.ticketForm.value.departamento!,
        edificio: this.ticketForm.value.edificio!,
        aula: this.ticketForm.value.aula!,
        detalles:this.ticketForm.value.detalle!,
        tipoMantenimiento:this.ticketForm.value.mantenimiento!,
        uso: this.ticketForm.value.uso!,
        fechaTicket:this.ticketForm.value.fecha!,
        tecnico: this.ticketForm.value.tecnico!,
        idEquipo:this.ticketForm.value.idEquipo!,
        estado: this.ticketForm.value.estado!,
        valoracion: this.ticketForm.value.valoracion!,
        comentario: this.ticketForm.value.comentario!, 
      
    }
    if(this.ticketForm.value.tecnico == "")
      {
        tickets.tecnico="No asignado";
      }
      if(this.ticketForm.value.valoracion=="")
      {
        tickets.valoracion="Sin valorar";
      }
      if(this.ticketForm.value.comentario =="")
      {
        tickets.comentario="Sin comentarios";
      }
      this.tik.crearTicket(tickets).then(r=>{
        this.alert.successful("Ticket registrado exitosamente");
        location.replace('tickets');
      }).catch(e=>{
        this.alert.error("Error: "+e.message);
      })    
  }
  actualizarTicket()
  {
    let ticket:Tickets={
            idTicket:this.ticketForm.value['idTicket'],
            aula:this.ticketForm.value['aula'],
            departamento:this.ticketForm.value['departamento'],
            detalles:this.ticketForm.value['detalle'],
            edificio:this.ticketForm.value['edificio'],
            estado:this.ticketForm.value['estado'],
            fechaTicket:this.ticketForm.value['fecha'],
            tecnico:this.ticketForm.value['tecnico'],
            tipoMantenimiento:this.ticketForm.value['mantenimiento'],
            uso:this.ticketForm.value['uso'],
            valoracion:this.ticketForm.value['valoracion'],
            comentario:this.ticketForm.value['comentario']
      
    } as Tickets;
    this.tik.updateTicket(ticket).then(r=>{
      this.alert.successful("El ticket se ha actualizado con exito");
      console.log(r);
      location.replace('tickets');
    }).catch(e=>{
      this.alert.error("Error: "+e.message);
    })
  }
  traerTecnicos()
  {
     return this.user.getUsers().subscribe(r => 
      {
        this.tecnico=r;
        
      })
      
  }
  traerIdEquipo()
   {
      return this.inv.getHardware().subscribe(r=>{
        this.idEquipo=r;
      })
   }
   traerIdEquipoPorDepartamento()
   {
    this.depaSelect=this.ticketForm.value.departamento;

   }
   traerUbicacionEquipo()
   {
    return this.inv.getEquipoId(this.ticketForm.value.idEquipo).subscribe(r=>{
    this.ticketForm.controls.edificio.setValue(r.edificio);
    this.ticketForm.controls.aula.setValue(r.aula)
   
    })
    
    
   }
   control()
   {
    console.log("Hola")
   }
   traerDetallesTecnico()
   {
    
    return this.user.getUser(this.ticketForm)
   }
   tecnicoSeleccionado()
   {
    if(this.ticketForm.value['tecnico']!="")
    {
      return true;
    }
    else{
      return false;
    }
   }
  getTicket(id:any){
    
    this.tik.getTicketsId(id).subscribe(r=>
      {
        this.ticketForm.controls.idTicket.setValue(r.idTicket);
        this.ticketForm.controls.aula.setValue(r.aula);
        this.ticketForm.controls.departamento.setValue(r.departamento);
        this.ticketForm.controls.detalle.setValue(r.detalles);
        this.ticketForm.controls.edificio.setValue(r.edificio);
        this.ticketForm.controls.estado.setValue(r.estado);
        this.ticketForm.controls.fecha.setValue(r.fechaTicket);
        this.ticketForm.controls.tecnico.setValue(r.tecnico);
        this.ticketForm.controls.mantenimiento.setValue(r.tipoMantenimiento);
        this.ticketForm.controls.uso.setValue(r.uso);
        this.ticketForm.controls.valoracion.setValue(r.valoracion);
        this.ticketForm.controls.comentario.setValue(r.comentario);
        return r;
      })
      
  }
}
