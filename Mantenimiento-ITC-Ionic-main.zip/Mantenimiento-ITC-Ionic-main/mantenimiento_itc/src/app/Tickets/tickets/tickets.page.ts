import { Component, OnInit } from '@angular/core';
import { stringify } from 'querystring';
import { Tickets } from 'src/app/Interfaces/tickets';
import { AlertsService } from 'src/app/Servicies/alerts.service';
import { InventoryService } from 'src/app/Servicies/inventory.service';
import { TicketsService } from 'src/app/Servicies/tickets.service';

@Component({
  selector: 'app-tickets',
  templateUrl: './tickets.page.html',
  styleUrls: ['./tickets.page.scss'],
})
export class TicketsPage implements OnInit {
  
  public type:any=localStorage.getItem('UserRol');
  public currentTecnico= localStorage.getItem('FullName');
  public depa:any=localStorage.getItem('UserDepartamento');
  public usuarioLogeado:any;
  tickets:Tickets[]=[];
  constructor(private ticket:TicketsService,private alert: AlertsService,private inv:InventoryService) { }

  ngOnInit() {
    this.usuarioLogeado=localStorage.getItem('FullName');
    this.obtenerTickets();
   
    
  }
  usuario()
  {
    location.replace("singleuser")
  }

  nuevoTicket()
   {
    localStorage.setItem('nuevoTicket',JSON.stringify(true));
    location.replace('tabla');
   }
   update(id:any)
   {
      localStorage.setItem('nuevoTicket',JSON.stringify(false));
      localStorage.setItem('ticketId',JSON.stringify(id));
      location.replace('tabla');
   }
   delete(id:any)
   {
    if (confirm("¿Estas seguro que deseas eliminar este ticket?")) {
      this.ticket.borrarTicket(id).then(r=>{
        this.alert.successful("Ticket eliminado con exito");
  
      }).catch(e=>{
        this.alert.error("Error: "+e.message);
      })
    
    
    }
   }
   obtenerTickets()
   {
    this.ticket.getTickets().subscribe(r=>
      {
        this.tickets=r;
        
      })
   }
   
}
