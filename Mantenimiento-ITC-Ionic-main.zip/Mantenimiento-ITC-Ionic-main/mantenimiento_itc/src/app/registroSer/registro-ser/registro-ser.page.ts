import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registro-ser',
  templateUrl: './registro-ser.page.html',
  styleUrls: ['./registro-ser.page.scss'],
})
export class RegistroSerPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
