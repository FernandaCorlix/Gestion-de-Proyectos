import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RegistroSerPage } from './registro-ser.page';

const routes: Routes = [
  {
    path: '',
    component: RegistroSerPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RegistroSerPageRoutingModule {}
