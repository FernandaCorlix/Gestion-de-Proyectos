import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { RegistroSerPageRoutingModule } from './registro-ser-routing.module';

import { RegistroSerPage } from './registro-ser.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RegistroSerPageRoutingModule
  ],
  declarations: [RegistroSerPage]
})
export class RegistroSerPageModule {}
