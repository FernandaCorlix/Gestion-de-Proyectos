import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';
import { environment } from 'src/environments/environment';
import { initializeApp } from "firebase/app";
import { AngularFireModule } from '@angular/fire/compat';
import { AngularFireAuthModule } from '@angular/fire/compat/auth';
import { AngularFireStorageModule } from '@angular/fire/compat/storage';
import { AngularFirestoreCollection, AngularFirestoreModule } from '@angular/fire/compat/firestore';
import { AngularFireDatabaseModule } from '@angular/fire/compat/database';
import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UsuarioPage } from './Usuario/usuario/usuario.page';
import { UsuarioPageModule } from './Usuario/usuario/usuario.module';
import { LoginPageModule } from './Login/login/login.module';
import { LoginPage } from './Login/login/login.page';
import { SingleuserPage } from './Usuario/SingleUser/singleuser/singleuser.page';
import { SingleuserPageModule } from './Usuario/SingleUser/singleuser/singleuser.module';

@NgModule({
  declarations: [AppComponent],
  imports: [BrowserModule, IonicModule.forRoot(), AppRoutingModule,
    AngularFireModule.initializeApp(environment.firebaseConfig),
    AngularFireAuthModule,
    AngularFirestoreModule,
    AngularFireStorageModule,
    AngularFireDatabaseModule,
    LoginPageModule,
    SingleuserPageModule,
    ReactiveFormsModule,
    ReactiveFormsModule],

  providers: [{ provide: RouteReuseStrategy, useClass: IonicRouteStrategy },LoginPage,SingleuserPage],
  bootstrap: [AppComponent],
})
export class AppModule {}
