import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertsService } from 'src/app/Servicies/alerts.service';
import { UserService } from '../../Servicies/user.service'


@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  type: string = "password";
  loginForm = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('', [Validators.required, Validators.minLength(6)]),
  });

  loading = false;
  constructor(private menuCtrl: MenuController,
    private rt: Router,
    private alert: AlertsService,
    private user: UserService) { }

  ngOnInit() {
  }

  changeType() {  // in your case function name is type
    if (this.type == 'password')
      this.type = 'text';
    else
      this.type = 'password';
  }

  ionViewWillEnter() {
    this.menuCtrl.enable(false);
    console.log(localStorage.getItem("logged"))
   }

   /*logIn()
   {

    location.replace("inventario")
   }*/
 
   logIn()
  {
    this.user.signInWithEmailAndPassword(this.loginForm.value).then(res=>{
      /*this.user.getUser((res['user']['uid'])).subscribe(u=>{
      /*this.user.getUser((res['user']['uid'])).subscribe(u=>*/
          
        localStorage.setItem("User",JSON.stringify(res.user?.uid));
         
        this.user.getUserWithMailAndPass(res.user?.uid).subscribe(u=>{
          this.alert.successful("Bienvenido a Mantenimeinto ITC "+u['Nombre']);
          localStorage.setItem('FullName',u['Nombre']+" "+u['Apellido']);
          localStorage.setItem('UserRol',u.Rol);
          localStorage.setItem('UserDepartamento',u.Departamento);
          this.logged(true);
          location.replace("inicio");
        });
  }).catch(e=>{
    this.alert.error("Error: "+e.message);
  })
}

logOut()
{
  this.alert.warning("Saliendo del Sistema de Mantenimeinto ITC").then(res=>
    {
  this.user.logout();
  this.logged(false);
  console.log(localStorage.getItem('logged'));
  location.replace('login');
    })}
    
logged(userLog:boolean)
{
  localStorage.setItem('logged',JSON.stringify(userLog));
  return userLog;
  
}
}
  
