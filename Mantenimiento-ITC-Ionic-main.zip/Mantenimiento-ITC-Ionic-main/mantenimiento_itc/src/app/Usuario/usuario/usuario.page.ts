import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/Servicies/user.service';
import { Usuarios } from 'src/app/Interfaces/usuarios';
import { User } from 'firebase/auth';
import { MenuController } from '@ionic/angular';
import { AlertsService } from 'src/app/Servicies/alerts.service';
import { Router } from '@angular/router';
import { LoginPage } from 'src/app/Login/login/login.page';
import { SingleuserPage } from '../SingleUser/singleuser/singleuser.page';

@Component({
  selector: 'app-usuario',
  templateUrl: './usuario.page.html',
  styleUrls: ['./usuario.page.scss'],
})
export class UsuarioPage implements OnInit {

   /*users=[{Nombre:"Eduardo",Apellido:"Uriarte",Correo:"theionicdiamond82@gmail.com",Contraseña:"12345",Departamento:"Sistemas y Tics",Rol:"Administrador"},
  {Nombre:"Fernanda",Apellido:"Cordoba",Correo:"corlix@gmail.com",Contraseña:"34567",Departamento:"Sistemas y Tics",Rol:"Tecnico"},
  {Nombre:"Briganny",Apellido:"Lead",Correo:"briganny@gmail.com",Contraseña:"98765",Departamento:"Sistemas y Tics",Rol:"Jefe de departameno"},
  {Nombre:"Eduardo",Apellido:"Uriarte",Correo:"theionicdiamond82@gmail.com",Contraseña:"12345",Departamento:"Sistemas y Tics",Rol:"Administrador"},
  {Nombre:"Fernanda",Apellido:"Cordoba",Correo:"corlix@gmail.com",Contraseña:"34567",Departamento:"Sistemas y Tics",Rol:"Tecnico"},
  {Nombre:"Briganny",Apellido:"Lead",Correo:"briganny@gmail.com",Contraseña:"98765",Departamento:"Sistemas y Tics",Rol:"Jefe de departameno"}]*/


  users:Usuarios[]=[];
  logged:any;
  usuario:any;
  public ulen=0;
  constructor(private us:UserService,
    private menuCtrl: MenuController,
    private alert: AlertsService,
    private router: Router,
    private login:LoginPage,
    private su:SingleuserPage) { }

  ngOnInit() {
    this.obtenerUsers();
    this.usuario=localStorage.getItem("FullName");
    
   
  }
  ionViewWillEnter() {
    
    /*this.logged=localStorage.getItem("logged");
    if(this.logged=='false')
    {
      this.menuCtrl.enable(false);
    }
    else{
      this.menuCtrl.enable(true);
    }*/
    
   
  }
  
  obtenerUsers()
  {
    this.us.getUsers().subscribe(r=>{
      this.users= r;
      
    })
    
  }
  
  delete(user:any)
  {
    if (confirm("¿Estas seguro que deseas eliminar a este usuario?")) {
      
          this.us.deleteUserAuth(user).then(d=>{
          }).catch(e=>{
            this.alert.error("Error: "+e.message);
          })
          this.us.borrarUser(user).then(r=>{
            this.alert.successful("El usuario fue eliminado con exito");
            this.login.logged(false);
      
          }).catch(e=>{
            this.alert.error("Error: "+e.message);
          })
        
        
    }
  }
 
  newUser(){
    localStorage.setItem("nuevoUsuario",JSON.stringify(true));
    location.replace('singleuser');
    
  }
  update(usuario:any)
  {
    localStorage.setItem("nuevoUsuario",JSON.stringify(false));
    localStorage.setItem("currentUser",JSON.stringify(false))
    localStorage.setItem("userDoc",usuario);
    location.replace('singleuser');
  }
}
