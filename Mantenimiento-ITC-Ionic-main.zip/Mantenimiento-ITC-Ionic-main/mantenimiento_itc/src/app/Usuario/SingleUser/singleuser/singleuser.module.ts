import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SingleuserPageRoutingModule } from './singleuser-routing.module';

import { SingleuserPage } from './singleuser.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,ReactiveFormsModule,
    IonicModule,
    SingleuserPageRoutingModule
  ],
  declarations: [SingleuserPage]
})
export class SingleuserPageModule {}
