import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SingleuserPage } from './singleuser.page';

const routes: Routes = [
  {
    path: '',
    component: SingleuserPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SingleuserPageRoutingModule {}
