import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { UsuarioPage } from '../../usuario/usuario.page';
import {UserService} from '../../../Servicies/user.service'
import { AlertsService } from 'src/app/Servicies/alerts.service';
import { Usuarios } from 'src/app/Interfaces/usuarios';
import { Router } from '@angular/router';

@Component({
  selector: 'app-singleuser',
  templateUrl: './singleuser.page.html',
  styleUrls: ['./singleuser.page.scss'],
})
export class SingleuserPage implements OnInit {
  currenUser:any;
  nuevo:any;
  uid:any;
  userID:any;
  rol:any;
  block:boolean=false;
  type: string = "password";
  userForm = new FormGroup({
    nombre:new FormControl('', [Validators.required]),
    apellido: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('', [Validators.required, Validators.minLength(6)]),
    disponibilidad: new FormControl('', [Validators.required]),
    especialidad: new FormControl('', [Validators.required]),
    rol: new FormControl('', [Validators.required]),
    departamento: new FormControl('', [Validators.required]),
  });
  constructor(private user:UserService,private alert:AlertsService,private router:Router) { }

  ngOnInit() {
    
  }
  ionViewWillEnter() {
    
    this.currenUser = localStorage.getItem("currentUser");
    this.nuevo = localStorage.getItem("nuevoUsuario");
    this.userID=this.replace(localStorage.getItem("User"),'"',"");
    if(this.nuevo=='false' && this.currenUser=='true')
    {
      this.cargarUsuario(this.userID);
    }
    else if(this.nuevo=='false' && this.currenUser=='false')
    {
    this.cargarUsuario(localStorage.getItem("userDoc"));
    }
    else if(this.nuevo=='true'){

    }
    this.rol=this.replace(localStorage.getItem("UserRol"),'"',"");
    if(this.rol!="Administrador")
    {
      this.block=true;
    }
    
    
    
  }
  replace(string:any,oldChar:string,newChar:string)
    {
        let len = string.length;
        let i;
        let newString:any="";
        for(i = 0; i < len; ++i)
        {
            if(string.charAt(i) == oldChar) 
                newString+= newChar;
            else
                newString += string.charAt(i);
        }
        return newString;
    }
  cargarUsuario(user:any){
    
    this.user.getUser(user).subscribe(r=>
      {
        this.userForm.controls.nombre.setValue(r.Nombre);
        this.userForm.controls.apellido.setValue(r.Apellido);
        this.userForm.controls.email.setValue(r.Correo);
        this.userForm.controls.password.setValue(r.Contraseña);
        this.userForm.controls.disponibilidad.setValue(r.Disponibilidad),
        this.userForm.controls.especialidad.setValue(r.Especialidad),
        this.userForm.controls.departamento.setValue(r.Departamento);
        this.userForm.controls.rol.setValue(r.Rol);
        return r;
      })
      
  }
  changeType() {  // in your case function name is type
    if (this.type == 'password')
      this.type = 'text';
    else
      this.type = 'password';
  }
  crearUsuario()
  {
    this.user.crearUsuarioAuth(this.userForm.value["email"] as string,this.userForm.value["password"] as string).then(auth=>{
      let user:Usuarios={
        id: auth.user?.uid,
        Nombre: this.userForm.value['nombre'],
        Apellido: this.userForm.value["apellido"],
        Correo: this.userForm.value['email'],
        Contraseña: this.userForm.value['password'],
        Disponibilidad:this.userForm.value['disponibilidad'],
        Especialidad: this.userForm.value['especialidad'],
        Departamento: this.userForm.value['departamento'],
        Rol:this.userForm.value['rol']
      } as Usuarios
      this.user.crearUsuarioData(user).then(r=>{
        this.alert.successful("Usuario creado exitosamente");
        location.replace('usuario');
      }).catch(e=>{
        this.alert.error("Error: "+e.message);
      })
    })
  }
  actualizarUsuario()
  {
    
    //console.log(this.auth['user']['uid']);
   
    //this.nombre = this.nameForm.value['name'];
    //this.descripcion = this.descForm.value['description'];
    let user:Usuarios={
      id: localStorage.getItem("userDoc"),
      Nombre: this.userForm.value['nombre'],
      Apellido: this.userForm.value["apellido"],
      Correo: this.userForm.value['email'],
      Contraseña: this.userForm.value['password'],
      Disponibilidad:this.userForm.value['disponibilidad'],
      Especialidad: this.userForm.value['especialidad'],
      Departamento: this.userForm.value['departamento'],
      Rol:this.userForm.value['rol']
      
    } as Usuarios;
    this.user.updateUser(user).then(r=>{
      if(user.id==this.userID)
      {
        localStorage.setItem('FullName',(this.userForm.value['nombre']+" "+this.userForm.value["apellido"]));
      }
      this.alert.successful("El usuario se ha actualizado con exito");
      location.replace('usuario');
    }).catch(e=>{
      this.alert.error("Error: "+e.message);
    })
    
    
  }
  getUserFullName()
  {
    this.user.getUser(this.uid).toPromise().then(
      g=>{
        localStorage.setItem("FullName",JSON.stringify(g?.Nombre+" "+g?.Apellido));
      })
    
  }

}
