import { Injectable } from '@angular/core';
import { Inventario } from '../Interfaces/inventario';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { map } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class InventoryService {

  constructor(private col:AngularFirestore) { }

      añadirEquipo(inv:Inventario)
    {
        return this.col.collection("Inventario").doc(inv.idEquipo).set(
      {
        
            idEquipo:inv.idEquipo,
            conectividad: inv.conectividad,
            uso: inv.uso,
            ram: inv.ram,
            fechaAdquisicion: inv.fechaAdquisicion,
            adquisicion: inv.adquisicion,
            edificio: inv.edificio,
            aula: inv.aula,
            tipo: inv.tipo,
            marca:inv.marca,
            sistemaOperativo: inv.sistemaOperativo,
            departamento: inv.departamento
    })
    }

    updateInventario(inv:Inventario)
    {
      return this.col.collection("Inventario").doc(inv.idEquipo).update({
       
        idEquipo:inv.idEquipo,
        conectividad: inv.conectividad,
        uso: inv.uso,
        ram: inv.ram,
        fechaAdquisicion: inv.fechaAdquisicion,
        adquisicion: inv.adquisicion,
        edificio: inv.edificio,
        aula: inv.aula,
        tipo: inv.tipo,
        marca:inv.marca,
        sistemaOperativo: inv.sistemaOperativo,
        departamento: inv.departamento
       }).then(r=>{
        return r;
      })
    }
    getHardware()
    {
      return this.col.collection("Inventario").snapshotChanges().pipe(map(res=>{
        return res.map(a=>{
          const data=a.payload.doc.data() as Inventario;
          data.idEquipo=a.payload.doc.id;
          return data;
        })
      }));
    }
    getHardwarePorDepartamento(departamento:any)
    {
      return this.col.collection("Inventario").snapshotChanges().pipe(map(res=>{
        return res.map(a=>{
          const data=a.payload.doc.data() as Inventario;
          data.idEquipo=a.payload.doc.id;
          return data.departamento;
        })
      }));
    }
    getUbicacionHardware()
    {
      return this.col.collection("Inventario").snapshotChanges().pipe(map(res=>{
        return res.map(a=>{
          const data=a.payload.doc.data() as Inventario;
          data.idEquipo=a.payload.doc.id;
          return data;
        })
      }));
    }
    borrarEquipo(id:any)
    {
      return this.col.collection("Inventario").doc(id).delete().then(r=>{
        return r;
      })
    }
    getEquipoId(idT:any){
      return this.col.collection("Inventario").doc(idT).get()
      .pipe(map(res=>{
        const data=res.data() as Inventario;
        data.idEquipo=idT;
        return data;
      }));
    }
}
