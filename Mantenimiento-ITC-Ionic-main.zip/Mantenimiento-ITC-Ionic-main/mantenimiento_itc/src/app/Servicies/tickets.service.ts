import { Injectable } from '@angular/core';
import { AngularFirestoreModule,AngularFirestoreCollection,AngularFirestoreDocument, AngularFirestore } from '@angular/fire/compat/firestore';
import { Tickets } from '../Interfaces/tickets';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class TicketsService {

  
  constructor(private col: AngularFirestore) { }

  crearTicket(tik:Tickets)
{
    return this.col.collection("Tickets").doc(tik.idTicket).set(
  {
    
    idTicket:tik.idTicket,
    departamento: tik.departamento,
    edificio: tik.edificio,
    aula: tik.aula,
    detalles: tik.detalles,
    tipoMantenimiento: tik.tipoMantenimiento,
    uso: tik.uso,
    fechaTicket: tik.fechaTicket,
    idEquipo:tik.idEquipo,
    tecnico: tik.tecnico,
    estado: tik.estado,
    valoracion: tik.valoracion,
    comentario: tik.comentario
})
}
getTickets()
{
  return this.col.collection("Tickets").snapshotChanges().pipe(map(res=>{
    return res.map(a=>{
      const data=a.payload.doc.data() as Tickets;
      data.idTicket=a.payload.doc.id;
      return data;
    })
  }));
  }
  getTicketsId(idT:any){
    return this.col.collection("Tickets").doc(idT).get()
    .pipe(map(res=>{
      const data=res.data() as Tickets;
      data.idTicket=idT;
      return data;
    }));
  }
  borrarTicket(id:any)
  {
    return this.col.collection("Tickets").doc(id).delete().then(r=>{
      return r;
    })
  }
  updateTicket(tik:Tickets)
  {
    return this.col.collection("Tickets").doc(tik.idTicket).update({
     
            idTicket:tik.idTicket,
            aula:tik.aula,
            departamento:tik.departamento,
            detalles:tik.detalles,
            edificio:tik.edificio,
            estado:tik.estado,
            fechaTicket:tik.fechaTicket,
            idEquipo:tik.idEquipo,
            tecnico:tik.tecnico,
            tipoMantenimiento:tik.tipoMantenimiento,
            uso:tik.uso,
            valoracion:tik.valoracion,
            comentario:tik.comentario
     }).then(r=>{
      return r;
    })
  }

}
