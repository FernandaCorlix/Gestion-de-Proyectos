import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { Auth,deleteUser} from '@angular/fire/auth';
import { AngularFirestoreModule,AngularFirestoreCollection,AngularFirestoreDocument, AngularFirestore } from '@angular/fire/compat/firestore';
import { map } from 'rxjs/operators';
import { getAuth, updateEmail } from "firebase/auth";

import { Usuarios } from '../Interfaces/usuarios';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  authr:any=getAuth();
  userD = this.authr.currentUser;
  constructor(private col: AngularFirestore,private fAuth: AngularFireAuth) { }

  public getUsers(){
    return this.col.collection("Usuarios").snapshotChanges().pipe(map(res=>{
      return res.map(a=>{
        const data=a.payload.doc.data() as Usuarios;
        data.id=a.payload.doc.id;
        return data;
      })
    }));
  }
  crearUsuarioAuth(correo: string, contraseña: string)
{
  return this.fAuth.createUserWithEmailAndPassword(correo.toLowerCase(),contraseña);
    /* signInWithEmailAndPassword(login) {
    return this.fAuth.signInWithEmailAndPassword(login.email, login.password).then(r => {
      return r;
    });*/ 
}
crearUsuarioData(user:Usuarios)
{
 
    return this.col.collection("Usuarios").doc(user.id).set(
  {
            id: user.id,
            Nombre: user.Nombre,
            Apellido: user.Apellido,
            Correo: user.Correo,
            Contraseña: user.Contraseña,
            Disponibilidad: user.Disponibilidad,
            Especialidad:user.Especialidad,
            Departamento: user.Departamento,
            Rol:user.Rol
})
}
  getUser(ids:any){
    return this.col.collection("Usuarios").doc(ids).get()
    .pipe(map(res=>{
      const data=res.data() as Usuarios;
      data.id=ids;
      return data;
    }));
  }
  getUserDetails(ud:Usuarios){
    return this.col.collection("Usuarios").doc(ud.id).get()
    .pipe(map(res=>{
      const data=res.data() as Usuarios;
      data.id=ud.id;
      return data;
    }));
  }
  getUserNames(){
    return this.col.collection("Usuarios").snapshotChanges().pipe(map(res=>{
      return res.map(a=>{
        const data=a.payload.doc.data() as Usuarios;
        data.id=a.payload.doc.id;
        return (data.Nombre+" "+data.Apellido);
      })
    }));
  }
  getUserName(ids:any){
    return this.col.collection("Usuarios").doc(ids).get()
    .pipe(map(res=>{
      const data=res.data() as Usuarios;
      data.id=ids;
      return (data.Nombre +" "+ data.Apellido);
    }));
  }
  getUserWithMailAndPass(uid:any){
    return this.col.collection("Usuarios").doc(uid).get()
    .pipe(map(res=>{
      const data=res.data() as Usuarios;
      data.id=uid;
      return data;
    }));
  }
  borrarUser(user:any)
  {
    return this.col.collection("Usuarios").doc(user).delete().then(r=>{
      return r;
    })
  }
  deleteUserAuth(userAD:any)
  {
    return deleteUser(userAD).then(r=>
      {
        return r;
      })
    
    //return this.auth. 
    //deleteUser(this.userD).then(d => {
     // return d;
    //})
  }
  updateUser(user:Usuarios)
  {

    
    return this.col.collection("Usuarios").doc(user.id).update({
     
            id: user.id,
            Nombre: user.Nombre,
            Apellido: user.Apellido,
            Correo: user.Correo,
            Contraseña: user.Contraseña,
            Disponibilidad: user.Disponibilidad,
            Especialidad:user.Especialidad,
            Departamento: user.Departamento,
            Rol:user.Rol
     }).then(r=>{
      return r;
    })
  }
  signInWithEmailAndPassword(login:any) {
    return this.fAuth.signInWithEmailAndPassword(login.email, login.password).then(r => {
      return r;
    });
  }
  logout()
  {
    return this.fAuth.signOut()
  }
}
