export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyAljxuQKYqw7TO6oZjH0GfmvlcdQsAOvzw",
    authDomain: "mantenimiento-itc.firebaseapp.com",
    projectId: "mantenimiento-itc",
    storageBucket: "mantenimiento-itc.appspot.com",
    messagingSenderId: "312097731873",
    appId: "1:312097731873:web:cc143151e904f513b73a60"
  }
};
